"""
Escribir una función max_in_list() que tome una lista de números y devuelva el más grande.
"""

list = [1, 2, 3, 4, 5, 10]

def max_in_list(list):
    return max(list)

print(max_in_list(list))